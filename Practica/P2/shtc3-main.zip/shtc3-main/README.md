# SHTC Driver
SHTC3 driver for ESP32 and STM32 devices
