#ifndef _AUX_H
#define _AUX_H

double senGrados(double x);
double cosGrados(double x);

#endif
